package com.hostel.model;

public class StandardResident extends StudentResident {
    public StandardResident(String name, String gender) {
        super(name, gender);
    }

    @Override
    public double calculateMessFees(int days) {
        return days * 50;
    }

    @Override
    public String getType() {
        return "Standard";
    }
}
