package com.hostel.model;

public abstract class StudentResident {
    private String name;
    private String gender;
    private double dues;
    private String roomId = "None";

    public StudentResident(String n, String g) {
        name = n;
        gender = g;
        dues = 0;
    }

    public String getName() { return name; }
    public String getGender() { return gender; }
    public double getDues() { return dues; }
    public String getRoomId() { return roomId; }

    public void setRoomId(String id) { roomId = id; }
    public void addDues(double d) { dues += d; }
    public void resetDues() { dues = 0; }

    public abstract double calculateMessFees(int days);
    public abstract String getType();
}
