package com.hostel.model;

public class ScholarshipResident extends StudentResident {
    private double discount;

    public ScholarshipResident(String n, String g, double d) {
        super(n, g);
        discount = d;
    }

    @Override
    public double calculateMessFees(int days) {
        double base = days * 50;
        return base * (1 - discount / 100);
    }

    @Override
    public String getType() {
        return "Scholarship";
    }

    public double getDiscountPercent() { return discount; }
}
