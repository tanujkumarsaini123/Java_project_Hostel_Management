package com.hostel.storage;

import java.io.*;
import com.hostel.model.StudentResident;
import com.hostel.room.Room;

public class Store {
    public static void save(StudentResident[] students, int sc, Room[] rooms, int rc) {
        try (PrintWriter pw = new PrintWriter("hostel_data.txt")) {

            pw.println("=== STUDENTS ===");
            for (int i = 0; i < sc; i++) {
                StudentResident s = students[i];
                pw.println(s.getName() + "," + s.getGender() + "," +
                           s.getType() + "," + s.getRoomId() + "," + s.getDues());
            }

            pw.println("\n=== ROOMS ===");
            for (int i = 0; i < rc; i++) {
                pw.println(rooms[i].toCSV());
            }

        } catch (Exception e) {
            System.out.println("Error saving file!");
        }
    }
}
