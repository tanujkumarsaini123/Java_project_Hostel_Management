package com.hostel.app;

import java.util.*;
import com.hostel.model.*;
import com.hostel.room.Room;
import com.hostel.storage.Store;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        StudentResident[] students = new StudentResident[50];
        Room[] rooms = new Room[20];
        int scount = 0, rcount = 0;

        System.out.print("Scholarship percent: ");
        double sp = Double.parseDouble(sc.nextLine());

        boolean run = true;

        while (run) {
            System.out.println("\n--- MENU ---");
            System.out.println("1 Add Student");
            System.out.println("2 Create Room");
            System.out.println("3 Allocate Room");
            System.out.println("4 Add Mess Fees");
            System.out.println("5 View Students");
            System.out.println("6 Save & Exit");
            System.out.print("Choice: ");

            String ch = sc.nextLine();

            try {

                switch (ch) {

                    case "1":
                        System.out.print("Name: ");
                        String n = sc.nextLine();
                        System.out.print("Gender (M/F): ");
                        String g = sc.nextLine();
                        System.out.print("1 Standard, 2 Scholarship: ");
                        String t = sc.nextLine();

                        if (t.equals("2"))
                            students[scount++] = new ScholarshipResident(n, g, sp);
                        else
                            students[scount++] = new StandardResident(n, g);
                        break;

                    case "2":
                        System.out.print("Room ID: ");
                        String id = sc.nextLine();
                        System.out.print("Gender limit (M/F/Any): ");
                        String gl = sc.nextLine();
                        System.out.print("Capacity: ");
                        int cap = Integer.parseInt(sc.nextLine());
                        rooms[rcount++] = new Room(id, gl, cap);
                        break;

                    case "3":
                        for (int i = 0; i < scount; i++)
                            System.out.println(i + ") " + students[i].getName());
                        System.out.print("Student index: ");
                        int si = Integer.parseInt(sc.nextLine());

                        for (int i = 0; i < rcount; i++)
                            System.out.println(i + ") " + rooms[i].getRoomId());
                        System.out.print("Room index: ");
                        int ri = Integer.parseInt(sc.nextLine());

                        rooms[ri].allocate(students[si]);
                        System.out.println("Allocated!");
                        break;

                    case "4":
                        System.out.print("Student index: ");
                        int ind = Integer.parseInt(sc.nextLine());
                        System.out.print("Days: ");
                        int d = Integer.parseInt(sc.nextLine());

                        double amt = students[ind].calculateMessFees(d);
                        students[ind].addDues(amt);

                        System.out.println("Added fees.");
                        break;

                    case "5":
                        for (int i = 0; i < scount; i++) {
                            StudentResident s = students[i];
                            System.out.println(s.getName() + " | " +
                                               s.getType() + " | Room:" +
                                               s.getRoomId() + " | Due:" + s.getDues());
                        }
                        break;

                    case "6":
                        Store.save(students, scount, rooms, rcount);
                        System.out.println("Saved. Bye!");
                        run = false;
                        break;
                }

            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        sc.close();
    }
}
