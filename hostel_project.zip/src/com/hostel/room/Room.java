package com.hostel.room;

import com.hostel.model.StudentResident;

public class Room {
    private String roomId;
    private String genderLimit;
    private StudentResident[] occupants;
    private int count = 0;

    public Room(String id, String g, int cap) {
        roomId = id;
        genderLimit = g;
        occupants = new StudentResident[cap];
    }

    public String getRoomId() { return roomId; }

    public void allocate(StudentResident s) throws Exception {
        if (count == occupants.length)
            throw new Exception("Room full!");

        if (!genderLimit.equalsIgnoreCase("Any") &&
            !genderLimit.equalsIgnoreCase(s.getGender()))
            throw new Exception("Gender not allowed!");

        occupants[count++] = s;
        s.setRoomId(roomId);
    }

    public String toCSV() {
        StringBuilder sb = new StringBuilder(roomId + "," + genderLimit + "," + occupants.length + ",");
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append(";");
            sb.append(occupants[i].getName());
        }
        return sb.toString();
    }
}
